package com.trade.generate;

public class ArchieveOldData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
