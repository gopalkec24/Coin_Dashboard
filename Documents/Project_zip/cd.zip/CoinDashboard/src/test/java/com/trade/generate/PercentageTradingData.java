package com.trade.generate;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.trade.constants.TraderConstants;
import com.trade.dao.AutoTradeVO;
import com.trade.dao.TradeDataVO;

public class PercentageTradingData {

	
	public static void main(String[] args) {
		addDataToExistingFile();
	//	addFreshData();
	}
	private static void addDataToExistingFile() {
		
		//2- KEEP_VOLUME
		//1- TAKE_AMOUNT
		// TODO Auto-generated method stub
		/*TradeDataVO tradeVO1= new TradeDataVO("BINANCE", "XLM", "USDT", new BigDecimal("0.00"), new BigDecimal("10.010"),TraderConstants.SELL_CALL);
		tradeVO1.setPlaceAvgPriceOrder(false);
		tradeVO1.setProfitType(2);
	//	tradeVO1.setBasePrice(new BigDecimal("0.00008666"));
		tradeVO1.setAdvanceTrade(false);
		tradeVO1.setBasePrice(new BigDecimal("0.123000"));
		tradeVO1.setMinPercentage(new BigDecimal("3"));
		tradeVO1.setMaxPercentage(new BigDecimal("1000"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "NEO", "USDT", new BigDecimal("0.00"), new BigDecimal("90.010"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
	//	tradeVO1.setBasePrice(new BigDecimal("0.00008666"));
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("12.0"));
		tradeVO2.setMinPercentage(new BigDecimal("7"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		
/*		TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "PHX", "ETH", new BigDecimal("0"), new BigDecimal("0.01001"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setBasePrice(new BigDecimal("0.00007900"));*/
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "XLM", "USDT", new BigDecimal("0"), new BigDecimal("15.52576"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setBasePrice(new BigDecimal("0.11416"));
		tradeVO2.setMinPercentage(new BigDecimal("1.5"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "TRX", "ETH", new BigDecimal("0"), new BigDecimal("0.027"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setBasePrice(new BigDecimal("0.00011197"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "BTC", "USDT", new BigDecimal("0.00199173"), new BigDecimal("0.00"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setBasePrice(new BigDecimal("7700"));
		tradeVO2.setMinPercentage(new BigDecimal("1.2"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "NEO", "USDT", new BigDecimal("0.0"), new BigDecimal("10.01"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setBasePrice(new BigDecimal("8.90"));
		tradeVO2.setMinPercentage(new BigDecimal("3"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
	/*	TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "XEM", "ETH", new BigDecimal("33.0"), new BigDecimal("0.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setBasePrice(new BigDecimal("0.00031"));
		tradeVO2.setMinPercentage(new BigDecimal("3"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
	/*	TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "ZRX", "ETH", new BigDecimal("45.0"), new BigDecimal("0.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setBasePrice(new BigDecimal("0.00122988"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));
		tradeVO2.setCyclic(true);*/
		
/*		TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "SC", "ETH", new BigDecimal("1163.0"), new BigDecimal("0.0"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setBasePrice(new BigDecimal("0.00000986"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));
		tradeVO2.setCyclic(true);*/
		
	/*	TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "ETH", "USDT", new BigDecimal("0.0"), new BigDecimal("10.10"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setBasePrice(new BigDecimal("230.00"));
		tradeVO2.setMinPercentage(new BigDecimal("20"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
	/*	TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "ETH", "BTC", new BigDecimal("0.0"), new BigDecimal("0.001001"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setBasePrice(new BigDecimal("0.034100"));
		tradeVO2.setMinPercentage(new BigDecimal("3"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "XRP", "ETH", new BigDecimal("0.00"), new BigDecimal("0.08813125"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setBasePrice(new BigDecimal("0.00149375"));
		tradeVO2.setMinPercentage(new BigDecimal("1.4"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
//		TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "KEY", "ETH", new BigDecimal("585.00"), new BigDecimal("0.00"),TraderConstants.SELL_CALL);
//		tradeVO2.setPlaceAvgPriceOrder(false);
//		tradeVO2.setProfitType(1);
//		tradeVO2.setAdvanceTrade(false);
//		tradeVO2.setBasePrice(new BigDecimal("0.0000171"));
//		tradeVO2.setMinPercentage(new BigDecimal("10"));
//		tradeVO2.setMaxPercentage(new BigDecimal("1000"));
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "ONT", "USDT", new BigDecimal("0.0"), new BigDecimal("10.0016"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("1.12"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
/*
		TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "TFUEL", "USDT", new BigDecimal("1876.0"), new BigDecimal("0.00"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.00533"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));
		*/
	/*	TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "ICX", "USDT", new BigDecimal("53.00"), new BigDecimal("0.00"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.2100"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
	/*	TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "VET", "ETH", new BigDecimal("0.00"), new BigDecimal("0.01950"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.00003000"));
		tradeVO2.setMinPercentage(new BigDecimal("13"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
	/*	TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "LTC", "USDT", new BigDecimal("0.12512500"), new BigDecimal("0.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("90.00"));
		tradeVO2.setMinPercentage(new BigDecimal("12"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
	/*	TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "TRX", "USDT", new BigDecimal("0.00"), new BigDecimal("26.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.03300"));
		tradeVO2.setMinPercentage(new BigDecimal("1.2"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "XRP", "USDT", new BigDecimal("0.00"), new BigDecimal("10.1"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setCyclic(true);
		tradeVO2.setAdditionalPercentge(new BigDecimal("0.5"));
		tradeVO2.setStopLossPercentage(new BigDecimal("1"));
		tradeVO2.setBasePrice(new BigDecimal("0.2682"));
		tradeVO2.setMinPercentage(new BigDecimal("1.5"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "TRX", "USDT", new BigDecimal("0.00"), new BigDecimal("16.0"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setCyclic(true);
		tradeVO2.setAdditionalPercentge(new BigDecimal("0.25"));
		tradeVO2.setStopLossPercentage(new BigDecimal("1"));
		tradeVO2.setBasePrice(new BigDecimal("0.02020"));
		tradeVO2.setMinPercentage(new BigDecimal("5.25"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));
		
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "BTC", "USDT", new BigDecimal("0.00"), new BigDecimal("10.1"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setCyclic(true);
		tradeVO2.setAdditionalPercentge(new BigDecimal("0.25"));
		tradeVO2.setStopLossPercentage(new BigDecimal("1"));
		tradeVO2.setBasePrice(new BigDecimal("9834.00"));
		tradeVO2.setMinPercentage(new BigDecimal("1.25"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "ZRX", "USDT", new BigDecimal("45.00"), new BigDecimal("0.00"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setCyclic(false);
		tradeVO2.setAdditionalPercentge(new BigDecimal("0.0"));
		tradeVO2.setStopLossPercentage(new BigDecimal("1"));
		tradeVO2.setBasePrice(new BigDecimal("0.33"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "BNB", "USDT", new BigDecimal("0.00"), new BigDecimal("17.00"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setCyclic(false);
		tradeVO2.setAdditionalPercentge(new BigDecimal("0.0"));
		tradeVO2.setStopLossPercentage(new BigDecimal("1"));
		tradeVO2.setBasePrice(new BigDecimal("23.32410000"));
		tradeVO2.setMinPercentage(new BigDecimal("8"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "XVG", "ETH", new BigDecimal("224.0"), new BigDecimal("0.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.00004500"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "NANO", "ETH", new BigDecimal("5.06"), new BigDecimal("0.0"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.005138"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
	/*	TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "DNT", "ETH", new BigDecimal("243"), new BigDecimal("0.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.000084"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "ZIL", "USDT", new BigDecimal("584.8"), new BigDecimal("0.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.0171"));
		tradeVO2.setMinPercentage(new BigDecimal("3"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		/*TradeDataVO tradeVO2= new TradeDataVO("BITSO", "BCH", "MXN", new BigDecimal("0.04168689"), new BigDecimal("0.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("6800.00"));
		tradeVO2.setMinPercentage(new BigDecimal("6"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));
		tradeVO2.setCyclic(true);
		tradeVO2.setAdditionalPercentge(new BigDecimal("0.75"));
		tradeVO2.setStopLossPercentage(new BigDecimal("2"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "BTC", "USDT", new BigDecimal("0.00400"), new BigDecimal("0.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("9540.00"));
		tradeVO2.setMinPercentage(new BigDecimal("2"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));
		tradeVO2.setCyclic(true);
		tradeVO2.setAdditionalPercentge(new BigDecimal("0.25"));
		tradeVO2.setStopLossPercentage(new BigDecimal("1.5"));*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("LIVECOIN", "DIG", "ETH", new BigDecimal("0.0"), new BigDecimal("0.01"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.00000380"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));
		tradeVO2.setAdditionalPercentge(new BigDecimal("0.0"));
		tradeVO2.setStopLossPercentage(new BigDecimal("2"));
		tradeVO2.setCyclic(true);*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "TRX", "USDT", new BigDecimal("0.0"), new BigDecimal("10.01"),TraderConstants.BUY_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.01983"));
		tradeVO2.setMinPercentage(new BigDecimal("9"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));
		tradeVO2.setAdditionalPercentge(new BigDecimal("0.0"));
		tradeVO2.setStopLossPercentage(new BigDecimal("1"));
		tradeVO2.setCyclic(true);*/
		
		/*TradeDataVO tradeVO2= new TradeDataVO("LIVECOIN", "DIG", "USD", new BigDecimal("1500.0"), new BigDecimal("0.00"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(1);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.00177"));
		tradeVO2.setMinPercentage(new BigDecimal("11"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "XRP", "USDT", new BigDecimal("0.0"), new BigDecimal("11.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setProfitType(2);
		tradeVO2.setAdvanceTrade(false);
		tradeVO2.setBasePrice(new BigDecimal("0.21994"));
		tradeVO2.setMinPercentage(new BigDecimal("10"));
		tradeVO2.setMaxPercentage(new BigDecimal("1000"));*/
		
		
		List<TradeDataVO> list = new ArrayList<TradeDataVO>();
		list.add(tradeVO2);
		String jsonFilePathNew = "C:/Documents/autotradeData4.json";
		AutoTradeVO tradeData;
		try 
		{
			tradeData = readAutoTradeDataFromJSONNew(jsonFilePathNew);
			List<TradeDataVO> list1=tradeData.getTradeData();
			list1.addAll(list);
			AutoTradeVO tradeDataVO = new AutoTradeVO();
			tradeDataVO.setLastUpdatedTime(new Date().getTime());
			tradeDataVO.setTradeData(list1);
			writeAutoTradeDataToJSON(jsonFilePathNew, tradeDataVO);
		} 
		catch (JsonSyntaxException e) 
		{			
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}
	
	private static AutoTradeVO readAutoTradeDataFromJSONNew(String jsonFilePath) throws JsonSyntaxException, IOException {
		Gson gson = new Gson();
		 Type listType = new TypeToken<AutoTradeVO>(){}.getType();
		 AutoTradeVO configValues= gson.fromJson(FileUtils.readFileToString(new File(jsonFilePath)),listType);
		return configValues;
	}

	
	private static void addFreshData() {
		TradeDataVO tradeVO1= new TradeDataVO("BINANCE", "ETH", "USDT", new BigDecimal("0.00"), new BigDecimal("10.30"),TraderConstants.BUY_CALL);
		tradeVO1.setPlaceAvgPriceOrder(false);
		tradeVO1.setAdvanceTrade(false);
		tradeVO1.setProfitType(2);
		tradeVO1.setCyclic(true);
		tradeVO1.setAdditionalPercentge(new BigDecimal("1"));
		tradeVO1.setStopLossPercentage(new BigDecimal("1.2"));
		tradeVO1.setBasePrice(new BigDecimal("172.80"));
		tradeVO1.setMinPercentage(new BigDecimal("10"));
		tradeVO1.setMaxPercentage(new BigDecimal("1000"));
		
		/*TradeDataVO tradeVO2= new TradeDataVO("BINANCE", "LTC", "USDT", new BigDecimal("0.18412"), new BigDecimal("0.0"),TraderConstants.SELL_CALL);
		tradeVO2.setPlaceAvgPriceOrder(false);
		tradeVO2.setAdvanceTrade(false);*/
		
		String jsonFilePathNew = "C:/Documents/autotradeData6.json";
		
		List<TradeDataVO> list = new ArrayList<TradeDataVO>();
		
		list.add(tradeVO1);
	//	list.add(tradeVO2);
		
		AutoTradeVO tradeDataVO = new AutoTradeVO();
		tradeDataVO.setLastUpdatedTime(new Date().getTime());
		tradeDataVO.setTradeData(list);
		writeAutoTradeDataToJSON(jsonFilePathNew, tradeDataVO);
	}
	private static void writeDataToFile(String jsonFilePathNew, List<TradeDataVO> list) {
		AutoTradeVO tradeDataVO = new AutoTradeVO();
		 Date dt = new Date();
		  tradeDataVO.setLastUpdatedTime(dt.getTime());
		  tradeDataVO.setTradeData(list);
		  writeAutoTradeDataToJSON(jsonFilePathNew, tradeDataVO);
	}
	private static void writeAutoTradeDataToJSON(String jsonFilePath, AutoTradeVO tradeDataVO) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			
			FileUtils.write(new File(jsonFilePath),mapper.defaultPrettyPrintingWriter().writeValueAsString(tradeDataVO));
		} catch (JsonGenerationException e) {
			
			e.printStackTrace();
		} catch (JsonMappingException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}
}
