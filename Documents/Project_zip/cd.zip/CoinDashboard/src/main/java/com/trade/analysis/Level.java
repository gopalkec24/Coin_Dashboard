package com.trade.analysis;

import java.math.BigDecimal;
import java.util.Date;

import com.trade.dao.binance.CLData;


public class Level {

	BigDecimal meanValue;
	int strength;
	CLData data;
	LevelType type;
	public Level(LevelType type,BigDecimal meanValue,int strength, CLData data) {
		this.type = type;
		this.data =data;
		this.meanValue =meanValue;
		this.strength = strength;
	}
	
	 
	public String toString() {
		return type.toString() + " Level Value : "+meanValue + "Level Strength : " + strength  +"  Opening Time : "  +new Date(data.getOpenTime()) + " Closing Time : " +new Date(data.getCloseTime()) + " \n";
		
	}


	public BigDecimal getMeanValue() {
		return meanValue;
	}


	public void setMeanValue(BigDecimal meanValue) {
		this.meanValue = meanValue;
	}


	public int getStrength() {
		return strength;
	}


	public void setStrength(int strength) {
		this.strength = strength;
	}


	public CLData getData() {
		return data;
	}


	public void setData(CLData data) {
		this.data = data;
	}


	public LevelType getType() {
		return type;
	}


	public void setType(LevelType type) {
		this.type = type;
	}
	
	
}
