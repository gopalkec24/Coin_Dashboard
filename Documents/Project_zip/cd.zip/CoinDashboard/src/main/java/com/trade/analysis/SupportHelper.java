package com.trade.analysis;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import com.trade.constants.TraderConstants;
import com.trade.dao.binance.CLData;
import com.trade.utils.TradeLogger;

public class SupportHelper implements ISupportResistanceHelper {

	public boolean withinRange(CLData node, BigDecimal rangePct, CLData compareNode) 
	{
		TradeLogger.LOGGER.finest("Min value " + node.getLow()+ " "+"Comparing value "+compareNode.getLow());
		BigDecimal threshold = node.getLow().multiply((new BigDecimal(1)).add((rangePct.divide(TraderConstants.HUNDRED))));
       TradeLogger.LOGGER.finest("Threshold value Calculation in Support Helper" + threshold);
		if (compareNode.getLow().compareTo(threshold) == TraderConstants.COMPARE_LOWER)
            return true;
        return false;
		
	}

	public CLData aggregate(List<CLData> datList) 
	{
		CLData lowestLowPrice = datList.get(0);
		for(int j=1; j< datList.size();j++)
		{
			if((datList.get(j).getLow().compareTo(lowestLowPrice.getLow())) == TraderConstants.COMPARE_LOWER) {
				lowestLowPrice= datList.get(j);
			}
		}
		return lowestLowPrice;
	}

	public LevelType type(BigDecimal meanValue , BigDecimal currentPrice ,BigDecimal rangePct) {
		
		BigDecimal threshold = meanValue.multiply((new BigDecimal(1)).subtract((rangePct.divide(TraderConstants.HUNDRED))));
		return meanValue.compareTo(threshold) == TraderConstants.COMPARE_LOWER ? LevelType.RESISTANCE : LevelType.SUPPORT;
	}
	
	public BigDecimal mean(List<CLData> dataList) {
		BigDecimal total =  TraderConstants.BIGDECIMAL_ZERO;
		for(CLData data : dataList) {
			total= total.add(data.getLow());
		}
		BigDecimal mean = total.divide(new BigDecimal(dataList.size()),RoundingMode.HALF_UP);
		return mean;
	}

}
