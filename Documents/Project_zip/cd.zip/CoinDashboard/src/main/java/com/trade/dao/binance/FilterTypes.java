package com.trade.dao.binance;

public class FilterTypes {


}
