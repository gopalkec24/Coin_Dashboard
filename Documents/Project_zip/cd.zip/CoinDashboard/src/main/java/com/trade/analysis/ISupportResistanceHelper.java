package com.trade.analysis;

import java.math.BigDecimal;
import java.util.List;

import com.trade.dao.binance.CLData;

public interface ISupportResistanceHelper {

	public CLData aggregate(List<CLData> datList);
	public boolean withinRange(CLData node, BigDecimal rangePct,  CLData compareNode);
	public BigDecimal mean(List<CLData> dataList);
	public LevelType type(BigDecimal meanValue , BigDecimal currentPrice ,BigDecimal rangePct);
}
