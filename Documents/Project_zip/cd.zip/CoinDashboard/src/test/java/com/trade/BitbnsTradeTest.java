package com.trade;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.json.JSONObject;

import com.trade.constants.TraderConstants;
import com.trade.dao.ATMarketStaticsVO;
import com.trade.dao.ATOrderDetailsVO;
import com.trade.exception.AutoTradeException;

public class BitbnsTradeTest {

	public static void main(String[] args) {
		BitbnsTrade trade = new BitbnsTrade();
		//Get the price history
	try {
		ATMarketStaticsVO market=trade.getExchangePriceStatics("BTC", "INR");
		System.out.println("LAst PRice " +market.getLastPrice());
		System.out.println("low price "+ market.getLowPrice());
		System.out.println("high price "+ market.getHighPrice());
		
		} catch (AutoTradeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	JSONObject body = new JSONObject();
	
	
		
		ATOrderDetailsVO placeOrderDetails = new ATOrderDetailsVO();
		placeOrderDetails.setCoin("BTC");		
		placeOrderDetails.setCurrency("INR");
		placeOrderDetails.setExchange("BITSO");
		BigDecimal orderPrice = new BigDecimal("600000.00");
		placeOrderDetails.setOrderPrice(orderPrice);
		placeOrderDetails.setOrderType(TraderConstants.BUY_CALL);
		placeOrderDetails.setOrderSubType(TraderConstants.LIMIT_ORDER);
		BigDecimal quantity = new BigDecimal("1000.00").divide(orderPrice,8,RoundingMode.HALF_UP);
		System.out.println("Quantitu " + quantity);		
		placeOrderDetails.setQuantity(quantity);
		System.out.println(quantity.toPlainString());
		
		trade.placeOrder(placeOrderDetails );
		//trade.getOrderStatus(placeOrderDetails);
		System.out.println("Is order placed "+ placeOrderDetails.isSuccess());
		System.out.println("Result Coede : "+ placeOrderDetails.getResultCode());
		System.out.println("ERror code :"+placeOrderDetails.getErrorMsg());
		 System.out.println("ORder id "+ placeOrderDetails.getOrderId());
		 System.out.println("ORder status "+ placeOrderDetails.getClientStatus());

	}

}
