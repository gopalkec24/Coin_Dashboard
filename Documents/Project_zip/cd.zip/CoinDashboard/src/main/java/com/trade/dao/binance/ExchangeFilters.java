package com.trade.dao.binance;

public class ExchangeFilters {
	
	String filterType;
	String maxNumOrders;

}
