package com.trade;

import java.math.BigDecimal;

import com.trade.constants.TraderConstants;
import com.trade.dao.TradeDataVO;

public class AutoTraderTest {

	public static void main(String[] args) throws Exception 
	{
	
		BigDecimal testdata = new BigDecimal("8.40");
	}
	
}
