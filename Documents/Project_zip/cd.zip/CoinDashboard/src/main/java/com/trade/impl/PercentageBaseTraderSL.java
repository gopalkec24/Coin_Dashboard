package com.trade.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Level;

import com.trade.ExchangeFactory;
import com.trade.ITrade;
import com.trade.constants.TraderConstants;
import com.trade.dao.ATMarketStaticsVO;
import com.trade.dao.ATOrderDetailsVO;
import com.trade.dao.TradeDataVO;
import com.trade.exception.AutoTradeException;
import com.trade.inf.IAutoTrader;
import com.trade.utils.TradeLogger;

public class PercentageBaseTraderSL extends PercentageBaseTrader  implements IAutoTrader{

	private static final String CLASS_NAME = "PercentageBaseTraderSL";

	public void processTradeList(List<TradeDataVO> listData) {
		// TODO Auto-generated method stub
		
	}

	public void processData(TradeDataVO tradeVO) {
		if(tradeVO.getTriggerEvent() == TraderConstants.COUNTER_NOINIT)
		{
			initializeLastPrice(tradeVO);				
		}
		else if(tradeVO.getTriggerEvent() == TraderConstants.INTITAL_TRIGGER)
		{
			TradeLogger.LOGGER.fine(tradeVO.toString());
			checkConditionTriggerTransaction(tradeVO);
		}
		else if(tradeVO.getTriggerEvent() == TraderConstants.PLACE_ORDER_TRIGGER)
		{
			orderToExchange(tradeVO);
		}
		else if(tradeVO.getTriggerEvent() == TraderConstants.ORDER_TRIGGERED) {
			
			checkOrderExecution(tradeVO);
		}
		else if(tradeVO.getTriggerEvent() == TraderConstants.ORDER_DELETED) {
			
			
		}
		else if(tradeVO.getTriggerEvent() == TraderConstants.MARK_FOR_DELETE_CREATE_NEW) {
			cancelOrderReTriggerForNewTradeCondition(tradeVO);
		}
		else if(tradeVO.getTriggerEvent() == TraderConstants.DELETE_FOR_NEWTRADE) {
			createNewTradeForDelete(tradeVO);
		}
		else if(tradeVO.getTriggerEvent() == TraderConstants.NEWTRADE_CREATED_FOR_DELETE) {
			tradeVO.setRemarks("Order was deleted and new order was created for same");
		}
		else if(tradeVO.getTriggerEvent() == TraderConstants.COMPLETED) {
			tradeVO.setRemarks("Order Got completed ");
		}
	}

	public void initializeLastPrice(TradeDataVO data) {
		
		super.initializeLastPrice(data);
	}

	public void checkConditionTriggerTransaction(TradeDataVO data) {

		ITrade trade = ExchangeFactory.getInstance(data.getExchange());
		//get the price from exchange 
		ATOrderDetailsVO placeOrder = null;
		try 
		{
			ATMarketStaticsVO marketStaticsVO = trade.getExchangePriceStatics(data.getCoin(), data.getCurrency());

			if(marketStaticsVO.isSuccess()) 
			{
				//check for price change after initializing the price
				checkAndChangeTriggerPrice(data, marketStaticsVO);
				
				BigDecimal orderPrice = data.getTriggeredPrice();
				try {
					if(data.getAdditionalPercentge()!= null && data.getReTriggerCount() <= 4) {
						if(data.getTransactionType() == TraderConstants.SELL_CALL)
						{
							orderPrice= calculateSellPriceForPercentage(data.getTriggeredPrice(),data.getAdditionalPercentge());
						}
						else if(data.getTransactionType() == TraderConstants.BUY_CALL)
						{
							orderPrice= calculateBuyPriceForPercentage(data.getTriggeredPrice(),data.getAdditionalPercentge());
						}
					}
				}
				catch(Exception e){
					TradeLogger.LOGGER.logp(Level.SEVERE, CLASS_NAME,"checkConditionTriggerTransaction" , "Error in calculating the percentage price setting the actual Price",e);
				}
				//Generating the order to exchange without any wait time
				placeOrder=generateOrderDetails(TraderConstants.LIMIT_ORDER,orderPrice ,null,data);
				//Checking the event and Placing the order
				if(data.getTriggerEvent() == TraderConstants.PLACE_ORDER_TRIGGER && placeOrder!= null) 
				{
					placeOrderToExchange(placeOrder);
					updateTradeData(data, placeOrder);
				}
				//updating the latest price value from Exchange to tradedata
				data.setPreviousLastPrice(data.getLastPrice());				
				data.setLowPrice(marketStaticsVO.getLowPrice());
				data.setHighPrice(marketStaticsVO.getHighPrice());
				data.setLastPrice(marketStaticsVO.getLastPrice());
			}
		}
		catch (AutoTradeException e) 
		{
			TradeLogger.LOGGER.logp(Level.SEVERE, CLASS_NAME,"checkConditionTriggerTransaction" , "Failed to get the Exchange price from server",e);
		}
	}

	public void orderToExchange(TradeDataVO data) {
		super.orderToExchange(data);
		
	}

	public void checkOrderExecution(TradeDataVO data) {
		super.checkOrderExecution(data);
		
	}

	public void cancelOrderReTriggerForNewTradeCondition(TradeDataVO data) {
		super.cancelOrderReTriggerForNewTradeCondition(data);
		
	}

	public void createNewTradeForDelete(TradeDataVO data) {
		super.createNewTradeForDelete(data);
		
	}

	public List<TradeDataVO> getNewTradeOrderList() {
		
		return newOrderList;
	}

}
