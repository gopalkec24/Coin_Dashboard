package com.trade.inf;

import java.math.BigDecimal;
import java.util.List;

import com.trade.constants.TraderConstants;
import com.trade.dao.TradeDataVO;

public interface IAutoTrader {
	
	public BigDecimal tradePercentage = TraderConstants.BIGDECIMAL_ZERO;
	
	public void processTradeList(List<TradeDataVO> listData);
	public void processData(TradeDataVO tradeVO);
	abstract void initializeLastPrice(TradeDataVO data);
	abstract void checkConditionTriggerTransaction(TradeDataVO data);
	abstract void orderToExchange(TradeDataVO data);
	abstract void checkOrderExecution(TradeDataVO data);
	abstract void cancelOrderReTriggerForNewTradeCondition(TradeDataVO data);
	abstract void createNewTradeForDelete(TradeDataVO data);
	abstract List<TradeDataVO> getNewTradeOrderList();
	
	
}
