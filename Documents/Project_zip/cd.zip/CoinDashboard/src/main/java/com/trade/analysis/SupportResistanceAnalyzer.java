package com.trade.analysis;

public class SupportResistanceAnalyzer {

}
