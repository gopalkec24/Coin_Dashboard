package com.trade.analysis;

public enum LevelType {
	 SUPPORT , RESISTANCE;
}
