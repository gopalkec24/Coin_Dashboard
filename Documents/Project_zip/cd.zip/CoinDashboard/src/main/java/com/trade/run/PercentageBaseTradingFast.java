package com.trade.run;

import com.trade.impl.AutoTraderExecutor;

public class PercentageBaseTradingFast {
	
	public static void main(String[] args) {
		String jsonFilePath = "C:/Documents/autotradeData6.json";
		String traderType= "PercentageBaseTraderFast";
		long waitTimeInMS = 100000;
		int executionFrequency = 80000;
		AutoTraderExecutor.startTrade(jsonFilePath, traderType, waitTimeInMS, executionFrequency);

	}

}
