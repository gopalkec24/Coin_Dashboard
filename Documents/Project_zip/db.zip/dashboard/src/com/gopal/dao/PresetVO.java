package com.gopal.dao;

public class PresetVO {

	String from;
	String where;
	String select;
	String preset;
	String cosa;
	
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getWhere() {
		return where;
	}
	public void setWhere(String where) {
		this.where = where;
	}
	public String getSelect() {
		return select;
	}
	public void setSelect(String select) {
		this.select = select;
	}
	public String getPreset() {
		return preset;
	}
	public void setPreset(String preset) {
		this.preset = preset;
	}
	public String getCosa() {
		return cosa;
	}
	public void setCosa(String cosa) {
		this.cosa = cosa;
	}
	
}
