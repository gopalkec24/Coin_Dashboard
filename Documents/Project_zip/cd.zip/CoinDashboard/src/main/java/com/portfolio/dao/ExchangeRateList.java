package com.portfolio.dao;

import java.util.List;
import java.util.Map;

public class ExchangeRateList {

	ExchangeRateVO[] rateList;

	/*public List<ExchangeRateVO> getRateList() {
		return rateList;
	}

	public void setRateList(List<ExchangeRateVO> rateList) {
		this.rateList = rateList;
	}*/
	
	//Map<String,String> rateMap;
	
	
	
	
}
