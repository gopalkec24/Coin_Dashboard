package com.trade.analysis;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.commons.collections.CollectionUtils;

import com.google.common.collect.Lists;
import com.trade.BinanceTrade;
import com.trade.constants.TraderConstants;
import com.trade.dao.ATMarketStaticsVO;
import com.trade.dao.binance.CLData;
import com.trade.exception.AutoTradeException;
import com.trade.utils.AutoTradeUtilities;
import com.trade.utils.TradeClient;
import com.trade.utils.TradeLogger;

public class TradeAnalysis
{
	public static WebTarget target = null;
   
	public static void main(String[] args) {
		
		TradeAnalysis analysis =new TradeAnalysis();
		try {
			int limit =0;
			BinanceTrade trade = new BinanceTrade();
			String coin = "XRP";
			String currency = "USDT";
			ATMarketStaticsVO marketstatus = trade.getExchangePriceStatics(coin, currency);
			
			List<CLData> datList = analysis.getCandleStickFromBinance(trade.getSymbolForExchange(coin, currency), "1d",limit);
			int segmentSize = 20;
			BigDecimal rangePer = new BigDecimal("1.5");
			analysisData(datList,marketstatus.getLastPrice(),segmentSize,rangePer);
		} catch (AutoTradeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private static void analysisData(List<CLData> datList, BigDecimal currentPrice, int segmentSize, BigDecimal rangePer) {
		int i=0;
		List<CLData> lowestLP = new CopyOnWriteArrayList<CLData>();
		List<CLData> highestHP = new CopyOnWriteArrayList<CLData>();
		CLData tempLow= null;
		CLData tempHigh = null;
		/*CLData overallLowPrice = null;
		CLData overallHighPrice = null;*/
		int compareHighPrice = 2;
		int compareLowPrice = 2;
		
		for(int j=0; j< datList.size();) {
			CLData data = datList.get(j);
			TradeLogger.LOGGER.finest("Open Time" +new Date( data.getOpenTime()).toString()+"Close Time" +new Date(data.getCloseTime()).toString());
			
			j++;
			if(i==0) 
			{
				tempHigh= data;
				tempLow = data;
				/*if(overallLowPrice ==null) {
					overallLowPrice = tempLow;
				}
				if(overallHighPrice == null) {
					overallHighPrice= tempHigh ;
				}*/
				
				
			}
			else if(data!=null) {
				//current low price is lesser than already found low price
				compareLowPrice = data.getLow().compareTo(tempLow.getLow());
				compareHighPrice = data.getHigh().compareTo(tempHigh.getHigh());
				if(compareLowPrice == TraderConstants.COMPARE_LOWER) {
					tempLow =data;
				}
				if(compareHighPrice == TraderConstants.COMPARE_GREATER) {
					tempHigh = data;
				}
				
			}
			i++;
			if(i==segmentSize || j== datList.size()) 
			{
				
				/*compareLowPrice = tempLow.getLow().compareTo(overallLowPrice.getLow());
				compareHighPrice = tempLow.getHigh().compareTo(overallHighPrice.getHigh());	
				if(compareLowPrice == TraderConstants.COMPARE_LOWER) 
				{
					overallLowPrice= tempLow;
				}
				if(compareHighPrice == TraderConstants.COMPARE_GREATER) 
				{
					overallHighPrice= tempHigh ;
				}*/
				lowestLP.add(tempLow);
				highestHP.add(tempHigh);
				tempLow =null;
				tempHigh = null;			
				i=0;
				compareLowPrice=2;
				compareHighPrice=2;
			}

		}
		TradeLogger.LOGGER.info(lowestLP.toString());
		TradeLogger.LOGGER.info(highestHP.toString());
		//To Print the values 
		/*i=0;
		for(CLData lowdata : lowestLP) {
			TradeLogger.LOGGER.info("Lowest "+ (i++) +" " + lowdata.getLow());
		}
		i=0;
		for(CLData highdata : highestHP) {
			TradeLogger.LOGGER.info("highest "+ (i++) +" "+highdata.getHigh());
		}*/
		List<Level> support = processData(lowestLP,currentPrice,rangePer, new SupportHelper());
		List<Level> resistance = processData(highestHP,currentPrice,rangePer,new ResistanceHelper());
		TradeLogger.LOGGER.info(support.toString());
		TradeLogger.LOGGER.info(resistance.toString());		
		smoothen(support,new BigDecimal("2.5"));
		smoothen(resistance,new BigDecimal("2.5"));
		TradeLogger.LOGGER.info(support.toString());
		TradeLogger.LOGGER.info(resistance.toString());
		
	//	TradeLogger.LOGGER.info("Overall Lowest low price "+overallLowPrice.getLow());
	//	TradeLogger.LOGGER.info("overall Highest High Price "+overallHighPrice.getHigh());
	}

	private static List<Level> processData(final List<CLData> dataList,BigDecimal currentPrice ,BigDecimal rangePct, ISupportResistanceHelper helper) {
		
		int k=0;
		List<CLData> values= new ArrayList<CLData>();
		List<Level> findingLevel  = new ArrayList<Level>();
		
		
		while(!dataList.isEmpty()) 
		{
			List<CLData> withinRange = new ArrayList<CLData>();
			Set<Integer> withinRangeIdx = new TreeSet<Integer>();
			 // Support/resistance level node
           CLData node = helper.aggregate(dataList);

            // Find elements within range
            for (int i = 0; i < dataList.size(); i++) {
                CLData f = dataList.get(i);
                if (helper.withinRange(node, rangePct, f)) {
                    withinRangeIdx.add(i);
                    withinRange.add(f);                    
                  //  dataList.remove(i);
                    TradeLogger.LOGGER.finest("Adding into Removal list" + i +" with Data "+ f.toString() + " Array Size "+ dataList.size());
                }
                if(node.getOpenTime() == f.getOpenTime()) {
                	withinRangeIdx.add(i);
                }
            }
            int adj=0;
            for(int i : withinRangeIdx) {
            	TradeLogger.LOGGER.finest("Remvoing ID " +i  + "  Adjustment ID " + adj + "Actual Size of array"  + dataList.size());
            	dataList.remove(i- adj++);
            }
            
            withinRange.add(node);
            BigDecimal meanValue= helper.mean(withinRange);
            values.add(node);
            TradeLogger.LOGGER.info("MEan value Calculated " + meanValue +" KK values "+k);
            k++;
           
            LevelType type=helper.type(meanValue, currentPrice, rangePct);
            findingLevel.add(new Level(type,meanValue,withinRange.size(),node));
            // Remove elements within range
            //CollectionUtils.removeAll(dataList, withinRangeIdx);
            TradeLogger.LOGGER.finest(dataList+"");
		}
		return findingLevel;
	}
	
	private static void smoothen(List<Level> levels,  BigDecimal rangePct) {
        if (levels.size() < 2)
            return;

        final List<Integer> removeIdx = Lists.newArrayList();
       // Collections.sort(levels);

        for (int i = 0; i < (levels.size() - 1); i++) {
             Level currentLevel = levels.get(i);
             Level nextLevel = levels.get(i + 1);
            BigDecimal current = currentLevel.getMeanValue();
            BigDecimal next = nextLevel.getMeanValue();
            BigDecimal difference =next.subtract(current).abs();
            BigDecimal threshold = (current.multiply(rangePct)).divide(TraderConstants.HUNDRED);

            if (difference.compareTo(threshold) == TraderConstants.COMPARE_LOWER) {
                final int remove = currentLevel.getStrength() >= nextLevel
                        .getStrength() ? i : i + 1;
                removeIdx.add(remove);
                i++; // start with next pair
            }
        }

        int adj=0;
        for(int i : removeIdx) {
        	TradeLogger.LOGGER.finest("Remvoing ID " +i  + "  Adjustment ID " + adj + "Actual Size of array"  + levels.size());
        	levels.remove(i- adj++);
        }
        
    }
	
	public static WebTarget getTarget(String apiEndPoint,boolean initaileNew) {
		if(target == null || initaileNew) {
			target = TradeClient.getAdvancedClient(apiEndPoint,true);
			TradeLogger.LOGGER.info("Initialized Newly ....");
		}
		return target;
	}
	public List<CLData> getCandleStickFromBinance(String symbol,String interval, int limit) throws AutoTradeException
	{
		
		 WebTarget target = getTarget("https://api.binance.com", false);
		 List<CLData> cldata = new ArrayList<CLData>();
		 target=target.path("api/v3/klines");
		 String repsonseStr= null;
		 if(AutoTradeUtilities.isNullorEmpty(symbol) || AutoTradeUtilities.isNullorEmpty(interval))
		 {
			 throw new AutoTradeException("symbol name or Currency cannot null value. Please pass the value." );
		 }
		 
		 target= target.queryParam("symbol", symbol);
		 target = target.queryParam("interval", interval);
		 if(limit >0) {
			 target =target.queryParam("limit", limit);
		 }
		 
		 Response response = target.request().get();
		 
		 if(response!= null && response.getStatus() == 200)
		 {
			 repsonseStr  = response.readEntity(String.class);	
			List<Object> object = (List<Object>) AutoTradeUtilities.getDAOObject(repsonseStr, List.class );
			
			mapData(object,cldata);
			TradeLogger.LOGGER.info(cldata.toString());
			//TradeLogger.LOGGER.info(repsonseStr);
		 }
		 else
		 {
			 repsonseStr  = response.readEntity(String.class);
			 TradeLogger.LOGGER.info(repsonseStr);
		 }
		 
		return cldata;
		
	}

	private void mapData(List<Object> object, List<CLData> cldataList) {
		
		for(Object obj : object) {
			List datas = (List) obj;
			CLData cldata = new CLData();
			for(int i=0;i<datas.size() ;i++)
			{
				Object data = datas.get(i);
				if(i==0) {
				 cldata.setOpenTime((Long) data);
				}
				else if(i==1) {
				cldata.setOpen(AutoTradeUtilities.getBigDecimalValue(data));
				}
				else if(i==2) {
				cldata.setHigh(AutoTradeUtilities.getBigDecimalValue(data));
				}
				else if(i==3) {
				cldata.setLow(AutoTradeUtilities.getBigDecimalValue(data));	
				}
				else if(i==4) {
				cldata.setClose(AutoTradeUtilities.getBigDecimalValue(data));	
				}
				else if(i==5) {
				cldata.setVolume(AutoTradeUtilities.getBigDecimalValue(data));	
				}
				else if(i==6) {
				cldata.setCloseTime((Long) data);	
				}
				else if(i==7) {
				cldata.setQuoteAssetVol(AutoTradeUtilities.getBigDecimalValue(data));
				}
				else if(i==8) {
				cldata.setTrades((Integer) data);
				}
				else if(i==9) {
				cldata.setTakerBuyBaseAssetVol(AutoTradeUtilities.getBigDecimalValue(data));	
				}
				else if(i == 10) {
				cldata.setTakerBuyQuoteAssetVol(AutoTradeUtilities.getBigDecimalValue(data));	
				}
				else {
				TradeLogger.LOGGER.finest(i +"  " +cldata.getClass().getName());
				}
			}
			cldataList.add(cldata);
		}
		
	}
	
}
