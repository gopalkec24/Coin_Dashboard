package com.gopal.currency;



public class CurrencyVO {
	
	private double USDINR;
	
	private double USDMXN;
	
	private double MXNINR;
	
	private double MXNUSD;
	
	private double INRMXN;
	
	private double INRUSD;

	public double getUSDINR() {
		return USDINR;
	}

	public void setUSDINR(double uSDINR) {
		USDINR = uSDINR;
	}

	public double getUSDMXN() {
		return USDMXN;
	}

	public void setUSDMXN(double uSDMXN) {
		USDMXN = uSDMXN;
	}

	public double getMXNINR() {
		return MXNINR;
	}

	public void setMXNINR(double mXNINR) {
		MXNINR = mXNINR;
	}

	public double getMXNUSD() {
		return MXNUSD;
	}

	public void setMXNUSD(double mXNUSD) {
		MXNUSD = mXNUSD;
	}

	public double getINRMXN() {
		return INRMXN;
	}

	public void setINRMXN(double iNRMXN) {
		INRMXN = iNRMXN;
	}

	public double getINRUSD() {
		return INRUSD;
	}

	public void setINRUSD(double iNRUSD) {
		INRUSD = iNRUSD;
	}


}
