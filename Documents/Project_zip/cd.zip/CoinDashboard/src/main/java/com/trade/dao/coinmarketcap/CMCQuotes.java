package com.trade.dao.coinmarketcap;

public class CMCQuotes {

	
}
