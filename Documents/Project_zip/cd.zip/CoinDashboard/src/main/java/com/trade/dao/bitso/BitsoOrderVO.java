package com.trade.dao.bitso;

public class BitsoOrderVO extends BitsoResponse {
	
	BitsoPayload payload;

	public BitsoPayload getPayload() {
		return payload;
	}

	public void setPayload(BitsoPayload payload) {
		this.payload = payload;
	}
	
	

}
